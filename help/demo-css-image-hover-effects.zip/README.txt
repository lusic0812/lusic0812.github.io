A Pen created at CodePen.io. You can find this one at http://codepen.io/nxworld/pen/ZYNOBZ.

 Article → http://www.nxworld.net/tips/css-image-hover-effects.html